const singleStorageUpload = require('./singleStorageUpload');
const LocalSingleStorage = require('./LocalSingleStorage');

module.exports = {
  singleStorageUpload,
  LocalSingleStorage,
};
